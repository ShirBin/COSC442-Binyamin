Last updated June 23, 2005 by Hopalong

Customs:
You can unzip the files and hand edit a unit
Copy a Heavy Metal Pro file into this folder
The Drawing Board free designer with newest patch, save as "xml" format
To match a unit with a gif (picture) you'll need to edit the "mechset" in mex folder

Mechs:
Changed some mech names (MFUK) when they are duplicated
dreadnoughts do not have internals
Blackjack/Ostroc/Scorpion (3050) have double heatsinks (this is official)
Shogun SHG-2E is a lvl2 mech

Vehs:
armor type: 0=standard 1=ferrofibrous
engine type: 0=fusion 1=ICE 2=xl

Condor Multi-Purpose Tank has hover movement, removed a front MG
J-27 and Mobile Longtom have trailers "combined" into 1 vehicle
Badger and Bandit are omnivehicles and are lvl2 tech
Revised Hover Tank and Weapons Carrier included

Infy:
Battletech					Megamek
-AntiBattlemech Attacks
Leg Attack					LegAttack
Swarm Attack					SwarmMek
						StopSwarm

-Armor
Basic Stealth					Basic Stealth
Fire Resistant					BA-Fire Resistant Armor
Improved Stealth				Improved Stealth
Mimetic						Mimetic Armor
Standard					(leave blank)
Standard Stealth				Standard Stealth

-Manipulators
Basic Manipulater				BA-Boarding Claw
Basic Manipulater (Mine Clearance)		Minesweeper
Battle Claw (Vibro) (1 claw)			BA-Vibro Claws (1)
Battle Claw (Vibro) (2 claws)			BA-Vibro Claws (2)
Salamander Claw (-1 to hit)			BA-Assault Claws

-Weapons
IS
ER Small Laser					BA-IS ER Small Laser
Firedrake Incendiary Needler			BA-Firedrake Incendiary Needler
Flamer						BA-Flamer
Heavy Grenade Launcher				BA-Auto GL
King David Light Gauss Rifle			BA-King David Light Gauss Rifle
David Light Gauss Rifle			BA-ISDavidLightGauss
Light Recoilless Rifle				BA-Light Recoilless Rifle

Machine Gun					BA-Machine Gun
Magshot Gauss Rifle				BA-Magshot GR
Mech Taser Rifle				BA-Mech Taser Rifle
Medium Laser					BA-IS Medium Laser
Medium Pulse Laser				BA-IS Medium Pulse Laser
Medium Recoilless Rifle				BA-Medium Recoilless Rifle
NARC						BA-Compact Narc
(2 shots)					BA-Compact Narc Ammo
Plasma Rifle					BA-Plasma Rifle
Small Laser					BA-Small Laser
SRM 2						SRM-2
(2 shots)					BA-SRM2 Ammo
(1 shot)					BA-SRM2 (one shot) Ammo
SRM 2 (Inferno)					BA-Inferno SRM
(1 shot)					BA-Inferno SRM Ammo
Support PPC					BA-Support PPC
Light Mortar				BA-ISLightMortar
Heavy Mortar				BA-ISHeavyMortar
Micro Grenade Launcher		BA-ISMicroGrenadeLauncher
Tsunami Heavy Gauss Rifle	BA-ISTsunamiHeavyGaussRifle
Grand Mauler				BA-ISGrandMauler
Light Anti-Vehicle Weapon	ISLAW
Light Anti-Vehicle Weapon 2	ISLAW2
Light Anti-Vehicle Weapon 3	ISLAW3
Light Anti-Vehicle Weapon 4	ISLAW4
Light Anti-Vehicle Weapon 5	ISLAW5
MRM 1						ISMRM1
MRM 2						ISMRM2
MRM 3						ISMRM3
MRM 4						ISMRM4
MRM 5						ISMRM5
MRM 1 Ammo (1 shot)			ISMRM1 Ammo
MRM 2 Ammo (1 shot)			ISMRM2 Ammo
MRM 3 Ammo (1 shot)			ISMRM3 Ammo
MRM 4 Ammo (1 shot)			ISMRM4 Ammo
MRM 5 Ammo (1 shot)			ISMRM5 Ammo
LRM 1						ISLRM1
LRM 2						ISLRM2
LRM 3						ISLRM3
LRM 4						ISLRM4
LRM 5						ISLRM5
LRM 1 Ammo (3 shots)		BAISLRM1 Ammo
LRM 2 Ammo (3 shots)		BAISLRM2 Ammo
LRM 3 Ammo (3 shots)		BAISLRM3 Ammo
LRM 4 Ammo (3 shots)		BAISLRM4 Ammo
LRM 5 Ammo (3 shots)		BAISLRM5 Ammo
LRM 5 Ammo (6 shots)		BALRM5 Ammo
Clan
Advanced SRM 2					Clan Advanced SRM-2
(2 shots)					BA-Advanced SRM-2 Ammo
Advanced SRM 5					BA-Advanced SRM-5
(2 shots)					BA-Advanced SRM-5 Ammo
Bearhunter Superheavy AC			BA-Bearhunter Superheavy AC
ER Small Laser					BA-Clan ER Small Laser
Medium Pulse Laser				BA-CL Medium Pulse Laser
SRM 2						CLSRM2
(1 shot)					BASRM2OS Ammo
Clan SRM 1					CLSRM1
Clan SRM 2					CLSRM2
Clan SRM 3					CLSRM3
Clan SRM 4					CLSRM4
Clan SRM 5					CLSRM5
Clan SRM 6					CLSRM6
Clan SRM 1 Ammo	(1 Shot)	BASRM1 Ammo
Clan SRM 2 Ammo	(2 Shots)	BASRM2 Ammo
Clan SRM 3 Ammo	(1 Shot)	BASRM3 Ammo
Clan SRM 4 Ammo	(1 Shot)	BASRM4 Ammo
Clan SRM 5 Ammo	(1 Shot)	BASRM5 Ammo
Clan SRM 6 Ammo	(1 Shot)	BASRM6 Ammo
Heavy Medium Laser			BA-CLHeavyMediumLaser
Heavy Small Laser			BA-CLHeavySmallLaser
Heavy Machine Gun			BA-HeavyMG
Light Machine Gun			BA-LightMG
Heavy Recoilless Rifle		BA-Heavy Recoilless Rifle
Small Pulse Laser			BA-CLSmallPulseLaser
Advanced SRM 1					Clan Advanced SRM-1
Advanced SRM 3					Clan Advanced SRM-3
Advanced SRM 4					Clan Advanced SRM-4
Advanced SRM 6					Clan Advanced SRM-6
Advanced SRM 1 Ammo	(1 shot)	BA-Advanced SRM-1 Ammo
Advanced SRM 2 Ammo (1 shot)	BA-Advanced SRM-2 Ammo OS
Advanced SRM 3 Ammo	(1 shot)	BA-Advanced SRM-3 Ammo
Advanced SRM 4 Ammo	(1 shot)	BA-Advanced SRM-4 Ammo
Advanced SRM 5 Ammo	(1 shot)    BA-Advanced SRM-5 Ammo OS
Advanced SRM 6 Ammo	(1 shot)	BA-Advanced SRM-6 Ammo
LRM 1							CLLRM1
LRM 2							CLLRM2
LRM 3							CLLRM3
LRM 4							CLLRM4
LRM 5							CLLRM5
LRM 1 Ammo	(3 shots)			BACLLRM1 Ammo
LRM 2 Ammo	(3 shots)			BACLLRM2 Ammo
LRM 3 Ammo	(3 shots)			BACLLRM3 Ammo
LRM 4 Ammo	(3 shots)			BACLLRM4 Ammo
LRM 5 Ammo	(3 shots)			BACLLRM5 Ammo

Squad Support (Trooper 1)
Flamer						IS Flamer
Machine Gun					BA-Single Machine Gun
Small Laser					IS Small Laser
Small Pulse Laser				BA-Single Small Pulse Laser

-Infantry
Corean Farshot LRM				Infantry LRM
Flamer						Infantry Flamer
Laser (Rifle)					Infantry Laser
MG						Infantry MG
Rifle						Infantry Rifle
SRM						Infantry SRM
SRM (Inferno)					Infantry Inferno SRM

-Specific
Flamer						BA-Twin Flamers
Machine Gun					Triple Machine Guns
Small Laser					Sloth Small Laser/Twin Small Lasers
Small Laser					Triple Small Lasers
Small Pulse Laser				Twin Small Pulse Lasers
SRM 4						BA-SRM4
(7 shots)					BA-SRM4 Grenadier Ammo
SRM 4						Fenrir SRM-4
(4 shots)					Fenrir SRM-4 Ammo
SRM 4						Phalanx SRM4
(2 shots)					Phalanx SRM4 Ammo 

-Equipment
Active Probe					Beagle Active Probe
Active Probe (Clan)
Camo System					Simple Camo
ECM						Single-Hex ECM
Improved Sensors				BAP (2 Hex)
Improved Sensors (Clan)				BAP (3 Hex)
Light TAG					Light TAG
Magnetic Clamps					BA-Magnetic Clamp
Mine Dispenser					BA-Mine Launcher
(1 shot)					BA-Mine Launcher Ammo
Parafoil					Parafoil
Searchlight					BASearchlight



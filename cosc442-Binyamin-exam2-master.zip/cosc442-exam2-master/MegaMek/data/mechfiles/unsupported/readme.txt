Directories named "unsupported" (and all their sub-directories) are
ignored when MegaMek loads units on startup.

This makes them a good place for official units that have technology
that is not yet supported by MegaMek.  You probably don't want to
place units that are "mostly supported" in here though.  For example:
the Phoenix Hawk PXH-7CS mech has an iNarc system (which is not yet 
supported), but MegaMek will load all the other equipment for that mech
just fine.

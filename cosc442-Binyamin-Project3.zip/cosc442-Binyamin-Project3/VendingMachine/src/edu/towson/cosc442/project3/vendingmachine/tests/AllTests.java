package edu.towson.cosc442.project3.vendingmachine.tests;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ VendingMachineItemTest.class, VendingMachineTest.class })
public class AllTests {

}

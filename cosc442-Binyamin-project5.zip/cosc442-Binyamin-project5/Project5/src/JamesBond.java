
public class JamesBond {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	
	public static boolean bondRegex(String input){
		if(input.contains("007"))
			return true;
		else
			return false;
	}

}
